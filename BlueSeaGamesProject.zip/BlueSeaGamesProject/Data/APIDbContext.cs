﻿using Microsoft.EntityFrameworkCore;
using _n2.Models;

namespace _n2.Data
{
    public class ApiDbContextcs : DbContext
    {

        // creazione delle tabelle
        public DbSet<Utente> Utente { get; set; }
        public DbSet<Gioco> Gioco { get; set; } 
        public DbSet<Piattaforma> Piattaforma { get; set; }







        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server= (localdb)\MSSQLLocalDB;Database=BlueSeaGamesDB");
        }
    } 
}

    