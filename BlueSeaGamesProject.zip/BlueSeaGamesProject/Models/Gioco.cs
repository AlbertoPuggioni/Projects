﻿namespace _n2.Models
{
    public class Gioco
    {
        public int id { get; set; }
        public string nome { get; set; }
        public string descrizione { get; set; }
        public double prezzo { get; set; }

     
    }
}
