﻿namespace _n2.Models
{
    public class Piattaforma
    {
        public int id { get; set; }
        public string nome { get; set; }
  
    }
}
