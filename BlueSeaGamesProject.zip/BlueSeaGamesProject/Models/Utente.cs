﻿namespace _n2.Models
{
    public class Utente
    {
        public int id { get; set; }
        public string nome { get; set; }
        public string cognome { get; set; }
        public string email { get; set; }
        public string password { get; set; }

        
    }
}