﻿using _n2.Data;
using _n2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using _n2.Data;
using _n2.Models;

namespace _2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtenteController : ControllerBase
    {
        ApiDbContextcs _dbContext = new ApiDbContextcs();

        //GET
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_dbContext.Utente);
        }
        //GET ID
        [HttpGet("{id}")]
        public IActionResult GetUtente(int id)
        {
            var utente = _dbContext.Utente.FirstOrDefault(x => x.id == id);

            return Ok(utente);
        }


        //POST
        [HttpPost]
        public IActionResult AggiungiUtente([FromBody] Utente utente)
        {
            _dbContext.Add(utente);
            _dbContext.SaveChanges();
            return StatusCode(StatusCodes.Status201Created);
        }



        //PUT
        [HttpPut("{id}")]
        public IActionResult Updateutente(int id, [FromBody] Utente updatedUtente)
        {
            var utente = _dbContext.Utente.Find(id);
            if (utente == null)
            {
                return BadRequest("Utente non aggiornabile!");
            }
            else
            {
                utente.nome = updatedUtente.nome;
                _dbContext.SaveChanges();
                return Ok();
            }
        }



        //DELETE
        [HttpDelete("{id}")]
        public IActionResult DeleteUtente(int id)
        {
            var utente = _dbContext.Utente.Find(id);
            if (utente == null)
            {
                return BadRequest(new { errorCode = 4, errorDescription = "Utente non trovata" });
            }
            else
            {
                _dbContext.Remove(utente);
                _dbContext.SaveChanges();
                return Ok();
            }
        }
    }
}