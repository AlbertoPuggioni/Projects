﻿using _n2.Data;
using _n2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using _n2.Data;
using _n2.Models;

namespace ProgettoBlueSeaGames.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GiocoController : ControllerBase
    {
        ApiDbContextcs _dbContext = new ApiDbContextcs();

        //GET
        //[HttpGet]
        //public IEnumerable<Gioco> Get()
        //{
        //    return _dbContext.Gioco;
        //}

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_dbContext.Gioco);
        }


        //[HttpGet("{id}")]
        //public Gioco GetGioco(int id) 
        //{
        //    var gioco = _dbContext.Gioco.FirstOrDefault(x => x.id == id);
        //    return gioco;
        //}

        [HttpGet("{id}")]
        public IActionResult GetGioco(int id)
        {
            var gioco = _dbContext.Gioco.FirstOrDefault(x => x.id == id);

            return Ok(gioco);
        }




        //POST
        //[HttpPost]
        //public void AggiungiGioco([FromBody] Gioco gioco)
        //{
        //    _dbContext.Add(gioco);
        //    _dbContext.SaveChanges();
        //}

        [HttpPost]
        public IActionResult AggiungiGioco([FromBody] Gioco gioco)
        {
            _dbContext.Add(gioco);
            _dbContext.SaveChanges();
            return StatusCode(StatusCodes.Status201Created);
        }


        //PUT
        //[HttpPut("{id}")]
        //public void ModificaGioco(int id, [FromBody] Gioco updatedGioco)
        //{
        //    var gioco = _dbContext.Gioco.Find(id);
        //    if(gioco != null) 
        //    {
        //        gioco.nome = updatedGioco.nome;
        //    }
        //    _dbContext.SaveChanges();
        //}
        [HttpPut("{id}")]
        public IActionResult Updategioco(int id, [FromBody] Gioco updatedGioco)
        {
            var gioco = _dbContext.Gioco.Find(id);
            if (gioco == null)
            {
                return BadRequest("Gioco non aggiornabile!");
            }
            else
            {
                gioco.descrizione = updatedGioco.descrizione;
                gioco.nome = updatedGioco.nome;
                _dbContext.SaveChanges();
                return Ok();
            }
        }



        //DELETE
        [HttpDelete("{id}")]
        public IActionResult DeleteGioco(int id)
        {
            var gioco = _dbContext.Gioco.Find(id);
            if (gioco == null)
            {
                return BadRequest(new { errorCode = 4, errorDescription = "gioco non trovata" });
            }
            else
            {
                _dbContext.Remove(gioco);
                _dbContext.SaveChanges();
                return Ok();
            }
        }
    }
}