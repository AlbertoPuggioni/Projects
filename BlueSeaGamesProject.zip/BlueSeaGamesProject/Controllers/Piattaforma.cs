﻿using _n2.Data;
using _n2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using _n2.Data;
using _n2.Models;

namespace _2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PiattaformaController : ControllerBase
    {
        ApiDbContextcs _dbContext = new ApiDbContextcs();

        //GET
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_dbContext.Piattaforma);
        }
        //GET ID
        [HttpGet("{id}")]
        public IActionResult GetPiattaforma(int id)
        {
            var piattaforma = _dbContext.Piattaforma.FirstOrDefault(x => x.id == id);

            return Ok(piattaforma);
        }


        //POST
        [HttpPost]
        public IActionResult AggiungiPiattaforma([FromBody] Piattaforma piattaforma)
        {
            _dbContext.Add(piattaforma);
            _dbContext.SaveChanges();
            return StatusCode(StatusCodes.Status201Created);
        }



        //PUT
        [HttpPut("{id}")]
        public IActionResult Updatepiattaforma(int id, [FromBody] Piattaforma updatedPiattaforma)
        {
            var piattaforma = _dbContext.Piattaforma.Find(id);
            if (piattaforma == null)
            {
                return BadRequest("Piattaforma non aggiornabile!");
            }
            else
            {
                piattaforma.nome = updatedPiattaforma.nome;
                _dbContext.SaveChanges();
                return Ok();
            }
        }



        //DELETE
        [HttpDelete("{id}")]
        public IActionResult DeletePiattaforma(int id)
        {
            var piattaforma = _dbContext.Piattaforma.Find(id);
            if (piattaforma == null)
            {
                return BadRequest(new { errorCode = 4, errorDescription = "Piattaforma non trovata" });
            }
            else
            {
                _dbContext.Remove(piattaforma);
                _dbContext.SaveChanges();
                return Ok();
            }
        }


    }
}